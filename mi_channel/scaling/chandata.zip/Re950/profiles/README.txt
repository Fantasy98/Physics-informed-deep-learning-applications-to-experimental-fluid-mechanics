This directory contains:
- Standard average profiles in wall-units:
           Re950.prof
- Standard deviation of these profiles:
           Re950.std
---------------------------------------------------------

Please report any problems with the data to S. Hoyas
sergio@torroja.dmt.upm.es
